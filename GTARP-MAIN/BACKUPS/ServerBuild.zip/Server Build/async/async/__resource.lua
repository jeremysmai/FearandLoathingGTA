resource_manifest_version '44febabe-d386-4d18-afbe-5e627f4af937'

description 'Async'

server_script 'async.lua'
client_script 'async.lua'