Locales['de'] = {
	['new_message'] = '~b~Neue Nachricht',
	['press_take_call'] = '%s - Drücke ~INPUT_CONTEXT~ um den Anruf anzunehmen',
	['taken_call'] = '~y~%s~s~ hat den Anruf angenommen',
	['gps_position'] = 'ziel in GPS eingegeben',
	['message_sent'] = 'nachricht gesendet',
	['cannot_add_self'] = 'du kannst dich nicht selbst hinzufügen',
	['number_in_contacts'] = 'diese Nummer ist bereits in deinen Kontakten',
	['contact_added'] = 'kontakt hinzugefügt',
	['contact_removed'] = 'the contact has been removed!',
	['number_not_assigned'] = 'diese Nummer ist nicht vergeben...',
	['invalid_number'] = 'that\'s not an valid number!',
}
